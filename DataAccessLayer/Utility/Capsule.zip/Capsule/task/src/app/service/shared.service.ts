import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import 'rxjs/Rx';
import { map } from "rxjs/operators";
import { Observable } from 'rxjs/Observable';
import { TaskModel } from '../model/taskmodel';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
 baseUrl:string='http://localhost:49324/api/Task/';
  constructor(private _http:Http) { }
  GetAllTask():Observable<TaskModel[]>
  {
    return this._http.get(this.baseUrl+"GetAllTask")
    .map((data:Response)=><TaskModel[]>data.json());
  }
  
  SearchTask(taskModel:Object):Observable<TaskModel[]>
  {
     return this._http.post(this.baseUrl+"SearchTask",{taskModel})
    .map((data:Response)=><TaskModel[]>data.json());
  }
  AddTask(taskModel:Object):Observable<boolean>
  {
    console.log(taskModel);
     return this._http.post(this.baseUrl+"AddTask",{ taskModel})
    .map((data:Response)=><boolean>data.json());
  }
  UpdateTask(taskModel:Object):Observable<boolean>
  {
     return this._http.post(this.baseUrl+"UpdateTask",{ taskModel})
    .map((data:Response)=><boolean>data.json());
  }
  DeleteTask(taskModel:Object):Observable<boolean>
  {
     return this._http.post(this.baseUrl+"DeleteTask",{ taskModel})
    .map((data:Response)=><boolean>data.json()); 
  }
  GetTaskById(id:Number):Observable<TaskModel>
  {
    return this._http.get(this.baseUrl+"GetTaskById",{ body: id})
    .map((data:Response)=><TaskModel>data.json()); 
  }
  
}
