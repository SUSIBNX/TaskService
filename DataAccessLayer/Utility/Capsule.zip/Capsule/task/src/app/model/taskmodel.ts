export class TaskModel {
    TaskId:number;
    ParentId:number;
    ParentTask:string;
    Task:string;
    StartDateString:string;
    EndDateString:string;
    StartDate:string;
    EndDate:string;
    Priority:number;
    PriorityEnd:number;
}
