import { Component, OnInit } from '@angular/core';

import{ SharedService } from '../service/shared.service';
import { TaskModel } from '../model/taskmodel';


@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
    list:TaskModel[];
    obj:TaskModel;
    returnObj:Boolean;
   
    ParentTask:string;
    Task:string;
    StartDate:string;
    EndDate:string;
    Priority:number;
  constructor(private _service:SharedService) 
  { 
    this.obj=new TaskModel();
  }
  ngOnInit() 
  {
  }
  AddTask()
  {
    this.obj=new TaskModel();
    this.obj.Task=this.Task;
    this.obj.ParentTask=this.ParentTask;
    this.obj.Priority=this.Priority;
    this.obj.StartDate=this.StartDate;
    this.obj.EndDate=this.EndDate;

    this._service.AddTask(this.obj)
    .subscribe(k=>this.returnObj=k);
  }
  GetAllTask()
  {
     this._service.GetAllTask()
    .subscribe(k=>this.list=k);
  }

}
