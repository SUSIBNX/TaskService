import { Component, OnInit } from '@angular/core';
import{ SharedService } from '../service/shared.service';
import { TaskModel } from '../model/taskmodel';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  list:TaskModel[];
  obj:TaskModel;
  returnObj:Boolean;
    ParentTask:string;
    Task:string;
    StartDate:string;
    EndDate:string;
    Priority:number;
  constructor(private _service:SharedService) 
  { 
    this.obj=new TaskModel();
  }

  ngOnInit() 
  {
  }
  UpdateTask()
  {
     this.obj=new TaskModel();
    this.obj.Task=this.Task;
    this.obj.ParentTask=this.ParentTask;
    this.obj.Priority=this.Priority;
    this.obj.StartDate=this.StartDate;
    this.obj.EndDate=this.EndDate;

    this._service.UpdateTask(this.obj)
    .subscribe(k=>this.returnObj=k)

  }
  GetAllTask()
  {
     this._service.GetAllTask()
    .subscribe(k=>this.list=k);
  }
}
